#include"Admin.h"
#include<iostream>

void admin::dsidplayAdminEmailPassword()
{
	cout << "Email: " << email << "\nPassword: " << password << endl;
}
void Admin::updateItemdetail() {
	std::cout << "Updated";
}
Admin::~Admin(){}