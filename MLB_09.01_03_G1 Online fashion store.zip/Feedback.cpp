#include"Feedback.h"
#include<iostream>
Feedback::Feedback(int fbNo) {
	feedbackNo = fbNo;
}
void Feedback::givefeedback() {

}
void Feedback::checkfeedback() {

}
void Feedback::DiplayFeedback(){
  std::cout << fbNo;
}
Feedback::~Feedback(){}