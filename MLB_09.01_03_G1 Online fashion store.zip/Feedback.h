class Feedback
{
public:
	int feedbackNo;

private:
	Feedback(int fbNo);
	void givefeedback();
	void checkfeedback();
  void Feedback::DiplayFeedback();
	~Feedback();
};