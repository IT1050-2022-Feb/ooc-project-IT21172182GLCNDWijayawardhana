class user
{
protected:
	char email[40];
	char password[20];
public:
	user();
	user(char mail[], char pass[]);
	void passwordValidation(char pass[]);
	void setEmailPass(char mail[], char pass[]);
};