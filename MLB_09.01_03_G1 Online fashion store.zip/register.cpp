#include <iostream>
#include "register.h"

using namespace std;

Register::Register(){
	registerid  = 0;
}
Register::Register(int rid){
	registerid = rid;
}
Register::validateReg_date(){
	
}
Register::storeData(){
	
}
Register::~Register(){
	
}