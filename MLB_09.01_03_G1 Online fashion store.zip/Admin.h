#pragma once
#include "user.h"

#include <iostream>
#include <string.h>

class Admin : public user
{
private:
	
public:
	Admin(char adminemail, char adminpass);
  void dsidplayAdminEmailPassword();
	void updateItemdetail();
	~Admin();
};
