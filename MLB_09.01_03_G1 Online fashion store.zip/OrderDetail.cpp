#include <iostream>
#include<cstring>
#include<string>
#include <ctime>
#include "class.h"
using namespace std;

void OrderDetail::setOrderDetail(int orId, int proId, int quaId){
	 int(orId = orId); 
	 int(proId= proId); 
	 int(quaId= quaId); 
} 
	 
void OrderDetail::DisplayOrderDetail(){ 
	 cout<< "orderId = " << orderId <<endl; 
	 cout<< "ProductID = " << productId <<endl; 
	 cout<< "QuaID = " << quality <<endl;
	 cout<<endl; 
}
	 
int main(){
	OrderDetail *or1 = new OrderDetail();
	OrderDetail *or2 = new OrderDetail();
	OrderDetail *or3 = new OrderDetail();
	
	return 0;
}