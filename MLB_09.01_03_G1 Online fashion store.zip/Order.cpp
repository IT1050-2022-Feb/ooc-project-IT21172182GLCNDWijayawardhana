#include <iostream>
#include<cstring>
#include<string>
#include <ctime>
#include "class.h"
using namespace std;

void Order::setOrder (int oId, int dateO, int cId){
	 int( orderId = oId); 
	 int( dateOrder= dateO); 
	 int( customerId= cId); 
} 
	 
void Order::DisplayOrder(){ 
	 cout<< "orderId = " << orderId <<endl; 
	 cout<< "dateOrder = " << dateOrder <<endl; 
	 cout<< "customerId = " << customerId <<endl;
	 cout<<endl; 
}
	 