#include <iostream>
#include "shoppingCart.h"
using namespace std;


ShoppingCart::ShoppingCart(){
	shoppingCartId = 0;
	productId = 0;
	quantity = 0;
	
}
ShoppingCart::ShoppingCart(int sId, int pId, int qua){
	
	shoppingCartId = sId;
	productId = pId;
	quantity = qua;
}
void ShoppingCart::addProduct(){
	
}
void ShoppingCart:: displayCartDetail()
{
  cout << "Shopping Cart ID :" << shoppingCartId << endl
<<"Product id :"<< productId << endl<<
"Product Quantity :"<<quantity<<endl;
}
ShoppingCart::~ShoppingCart(){
	
}