class unregisteredCustomer
{
public:
	void             registerToWebSite();
	void viewWebSite();
};

