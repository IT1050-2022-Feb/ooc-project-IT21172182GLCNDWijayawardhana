#include "user.h"
#include<string.h>

user::user()
{
	strcpy(email, "");
	strcpy(password, "");
}
user::user(char mail[],char pass[])
{
	strcpy(email, mail);
	strcpy(password, pass);
}
void user:: passwordValidation(char pass[])
{

}
void user:: setEmailPass(char mail[],char pass[])
{
	strcpy(email, mail);
	strcpy(password, pass);
}
