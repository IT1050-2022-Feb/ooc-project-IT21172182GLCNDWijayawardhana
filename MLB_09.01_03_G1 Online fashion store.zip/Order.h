#include <iostream>
#include<cstring>
#include<string>
#include <ctime>
using namespace std;

//Order class
class Order{
	private:
		int orderId;
		int dateOrder;
		int customerId;
	public:
		void DisplayOrder();
		void placeOrder();
		void setOrder(int oId, int dateO, int cId);
		
};

//order details class
class OrderDetail{
	private:
		int orderId;
		int productId;
		int quality;
	public:
		void DisplayOrderDetail();
		void setOrderDetail(int orId, int proId, int quaId);
		void calPrice();
		
};
