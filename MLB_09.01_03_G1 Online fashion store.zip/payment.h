//Payment class
class Payment
{
private:
  int paymentID;

public:
  Payment();
  Payment(int pID);
  void confirmPayment();
  void displayPaymentDetails();
};