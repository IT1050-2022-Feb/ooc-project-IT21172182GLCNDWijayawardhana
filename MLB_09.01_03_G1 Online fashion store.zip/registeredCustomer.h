#pragma once
#include "user.h"
#include "soppingCart.h"
#include "Order.h"

#include <iostream>
#include <string.h>
using namespace std;

class registeredCustomer : public user
{
private:
	int cstomerID;
	char customeNname[30];
	char customerAddress[30];
	int customerMobile;
public:
	void dsidplayEmailPassword();
	registeredCustomer();
	registeredCustomer(int uId, char cName[], char cAddress[], int cMobile, int cartId1, int cartId2, int itemId1, float price1, int itemId2, float price2);
	void set_Display(int uId, char cName[], char cAddress[], int cMobile);
	void addToCart();
  void addOrder(Order *O);
  void Display();
	void givFeedback();
	void registerCustomer();
	~registeredCustomer();
};

