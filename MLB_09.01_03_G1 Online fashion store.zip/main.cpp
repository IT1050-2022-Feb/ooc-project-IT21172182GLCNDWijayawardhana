#include "user.h"
#include "registeredCustomer.h"
#include "unregisteredCustomer.h"
#include "register.h"
#include "shoppingCart.h"
#include "Order.h"

#include <iostream>
using namespace std;

int main()
{
    
  cout << "Registered Customer" << endl; 
	registeredCustomer r;
	r.setEmailPass("chamikar22@gmail.com","abcd12345@");
	r.dsidplayEmailPassword();
	r.set_Display(21170416,"Chamika","Kegalle", 0714740710);
	
  //Register
  Register R;
  R.Register();
  R.Register(1100);
  //shopping Cart
  cout<<"Shopping Cart"<<endl;
  ShoppingCart r;
  r.ShoppingCart();
  r.ShoppingCart(21172182,1100,10);
  r.displayCartDetail();
  r->addToCart();
  
  //order
 //  Order *o1 = new Order();
	// Order *o2 = new Order();
	// Order *o3 = new Order();
  
  order *01 = new Order("001",C1);
  order *02 = new Order("002",C2);

  cout << "orders of" << endl;
  
  r.Display(); // Display registeredCustomer

  char ch;
  cin >> ch;

  
  //Aamin
  cout << "admin" << endl; 
  Admin a;
  a.setEmailPass("abc@gmail.com","#123pqr");
  a.dsidplayAdminEmailPassword();
    
	Feedback *f = new Feedback("");
  f->givefeedback("",f);
  f->DiplayFeedback();

   
	  return 0;
  
  }
