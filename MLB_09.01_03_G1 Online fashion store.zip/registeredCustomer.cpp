#include "registeredCustomer.h"
#include "user.h"
#include "soppingCart.h"
#include "Order.h"

#include <string.h>

using namespace std;

void registeredCustomer::dsidplayEmailPassword()
{
	cout << "Email: " << email << "\nPassword: " << password << endl;
}

registeredCustomer::registeredCustomer() {

	cstomerID = 0;
	strcpy(customeNname, "");
	strcpy(customerAddress, "");
	customerMobile = 0;
  CartD[0] = new ShoppingCart(145);
	CartD[1] = new ShoppingCart(434);
  
}
registeredCustomer::registeredCustomer(int uId, char cName[], char cAddress[], int cMobile,int cartId1, int cartId2,int itemId1, float price1, int itemId2, float price2)
{
	cstomerID = uId;
	strcpy_s(customeNname, cName);
	strcpy_s(customerAddress, cAddress);
	customerMobile = cMobile;
  CartD[0] = new ShoppingCart(cartId1);
	CartD[1] = new ShoppingCart(cartId2);
  noOfOrders = 0;
}

void registeredCustomer::set_Display(int uId,char cName[],char cAddress[], int cMobile)
{
	cstomerID = uId;
	strcpy_s(customeNname, cName);
	strcpy_s(customerAddress, cAddress);
	customerMobile = cMobile;
}

void registeredCustomer:: givFeedback()
{
    
}
void registeredCustomer::addToCart()
{
      for (int i = 0; i < SIZE; i++)
	    {
		    CartD[i]->displayCartDetail();
	    }
}
void registeredCustomer::addOrder(Order *O)
{
	if (noOfOders < SIZE)
		OrderD[noOfOders] = 0;
  
  noOfOders++;
}
void registeredCustomer::Display()
{
	cout <<"cstomerID : "  << cstomerID << endl;
	cout <<"customeNname :" << customeNname << endl;
	cout <<"customerAddress:" << customerAddress << endl;
	cout <<"customerMobile :" << customerMobile << endl;
  for(int i =0 ; i< noOfOders;i++)
  {
    order[i]->displayOrders();
  }
}
registeredCustomer::~registeredCustomer()
{
      	cout << "Registered Customer Shutting down" << endl;

	      for (int i = 0; i < SIZE; i++)
	      {
          delete OrderD[i];
		      cout << "the Oreders are End" << endl;
          
          delete CartD[i];
		      cout << "the cart is End" << endl;
	      }
}

