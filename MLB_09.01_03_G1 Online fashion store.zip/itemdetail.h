#include <iostream>
#include<cstring>
#include<string>
#include <ctime>
using namespace std;

//item details class
class ItemDetail{
	private:
		int itemId;
		float itemPrice;
		char itemDescription;
	public:
		ItemDetail(int itemId, float pri, char desc);
		void displayItemDetails();
		~ItemDetail();
};