#include <iostream>
#include<cstring>
#include"payment.h"

using namespace std;

void Payment::payment(int Pid, char * payDesc){
}
 

void payment::displayPaymentDetails(){
	cout<<"Payment ID:"<<pID<<endl;
  cout<<"Payment payDesc:"<<payDesc<<endl;
}

  
}
void payment::getPaymentDetails()
{
  
}