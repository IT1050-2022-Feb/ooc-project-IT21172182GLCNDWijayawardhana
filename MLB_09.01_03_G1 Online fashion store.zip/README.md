# ooc project-MLB_09.01_03

 <table>
   <tr>
     <th>Register</th>
     <th>Name</th>
     <th>contact number</th>
     <tr>
     <td>IT21172182</td>
     <td>G.L.C.N.D Wijayawardhana</td>
    <td>0763610570</td>
   </tr>
   <tr>
     <td>IT21170584</td>
     <td>K.G.P Sithumini</td>
     <td>0779233384</td>
     </tr>
   <tr>
     <td>IT21170416</td>
<td>I.R.C Pemarathna</td>
<td>0714740710</td>
   </tr>
  <tr>
    <td>IT21169762</td>
    <td>S.D Keegal</td>
    <td>0769191827</td>
  </tr>
   <tr>
     <td>IT21171192</td>
     <td>R.M.D.A Rathnayaka</td>
     <td>0702715474</td>
   </tr>
 </table>

 

