#include "itemdetail.h"
#include<string.h>
using namespace std;

int main(){
  void ItemDetail::itemdetail (int iId){
	 int( itemdetailId = iId);
	} 
	 
	void ItemDetail::itemdetail(){ 
	 cout<< itemId <<endl; 
	 cout<<endl; 
	 }
	return 0;
}