#include<iostream>
#include "itemdetail.h"
#include "shoppingCart.cpp"
class ShoppingCart{

	private:

		int shoppingCartId;
		int productId;
		int quantity;

	public:
      ShoppingCart();
		  ShoppingCart(int sId, int pId, int qua);
		  void addProduct();
      void displayCartDetail();
		  ~ShoppingCart();      
};