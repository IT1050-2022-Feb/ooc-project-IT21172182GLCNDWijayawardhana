#include<iostream>
#include<cstring>
#include "unregisteredCustomer.h"
#include "register.cpp"
//Register class

class Register
{
	private:
		 int registerid;
		 
    public:
    	Register();
    	Register(int rid);
    	void validateReg_date();
    	void storeData();
    	~Register();
    	
};

